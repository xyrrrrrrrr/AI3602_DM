from .visitor import Visitor
# from visitor import Visitor
from typing import List

class MethodDeclarationVisitor(Visitor):
    def __init__(self):
        super().__init__()
        self.method_names = []

    def get_method_names(self, code: str) -> List[str]:
        tree = self.parser.parse(code.encode())
        root = tree.root_node
        if root.has_error:
            raise ValueError('original code is invalid')
        children = root.children[0].children[3]
        for child in children.children:
            if child.type == 'method_declaration':
                # get method name
                maybe_method_name = [c for c in child.children]
                for maybe_name in maybe_method_name:
                    if maybe_name.type == 'identifier':
                        self.method_names.append(maybe_name.text.decode())
        return self.method_names
if __name__ == '__main__':
    visitor = MethodDeclarationVisitor()
    visitor.get_method_names('''
          public class MyClass {
            public void readText(String file) { 
              System.out.println('Hello World.'); 
            }
            public static void printName() {
              System.out.println("MyClass");
            }
          }
        ''')
    print(visitor.method_names)
