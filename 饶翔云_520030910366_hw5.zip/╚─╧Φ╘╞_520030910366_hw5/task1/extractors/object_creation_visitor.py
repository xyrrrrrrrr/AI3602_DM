from .visitor import Visitor
# from visitor import Visitor
from typing import List


class ObjectCreationVisitor(Visitor):
    def __init__(self):
        super().__init__()
        self.object_creation_list = []

    def get_object_creations(self, code: str) -> List[str]:
        tree = self.parser.parse(code.encode())
        root = tree.root_node
        if root.has_error:
            raise ValueError('original code is invalid')
        class_body = root.children[0].children[3]
        for child in class_body.children:
            if child.type == 'method_declaration':
                self._get_object_creation(child)
        return self.object_creation_list
    
    def _get_object_creation(self, method_declaration):
        for child in method_declaration.children:
            if child.type == 'block':
                for c in child.children:
                    if c.type == 'local_variable_declaration':
                        for cc in c.children:
                            if cc.type == 'type_identifier':
                                self.object_creation_list.append(cc.text.decode())
                                print(cc.text.decode())
                            if cc.type == 'variable_declarator':
                                for ccc in cc.children:
                                    if ccc.type == 'object_creation_expression':
                                        for cccc in ccc.children:
                                            if cccc.type == 'argument_list':
                                                for ccccc in cccc.children:
                                                    if ccccc.type == 'object_creation_expression':
                                                        for cccccc in ccccc.children:
                                                            if cccccc.type == 'type_identifier':
                                                                self.object_creation_list.append(cccccc.text.decode())
                                                                print(cccccc.text.decode())
                                
if __name__ == '__main__':
    visitor = ObjectCreationVisitor()
    visitor.get_object_creations("public class MyClass {    public void readText(String file) {         BufferedReader br = new BufferedReader(new FileInputStream(file));    }}")