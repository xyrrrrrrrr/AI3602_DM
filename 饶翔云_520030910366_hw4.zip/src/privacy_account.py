import numpy as np
from scipy.integrate import quad
import math

"""
Optionally you could use moments accountant to implement the epsilon calculation.
"""
"""
reference: github.com/tensorflow/privacy/blob/master/tutorials/mnist_dpsgd_tutorial.py
"""
def method_E_1(x, q, sigma, order, sensitivity):
    """
    The first method to calculate E.
    """
    coef = np.exp(-1 * (x ** 2) / (2 * sigma**2)) / (np.sqrt(2 * np.pi) * sigma)
    pow = 1 / (1 - q + q * np.exp((2 * sensitivity * x - 1) / (2 * sigma**2)))
    result = coef * pow**order
    return result

def method_E_2(x, q, sigma, order, sensitivity):
    """
    The second method to calculate E.
    """
    coef = (q*np.exp(-1 * ((x - sensitivity)**2) / (2 * sigma**2)) + (1 - q) * np.exp(-1 * (x**2) / (2 * sigma**2))) / (np.sqrt(2 * np.pi) * sigma)
    pow = (1 - q + q * np.exp((2 * sensitivity * x - 1) / (2 * sigma**2)))
    result = coef * pow**order
    return result

def calculate_epsilon(q, sigma, steps, order, delta, sensitivity):
    """
    Calculate epsilon with given q, sigma, steps, order, delta and sensitivity.
    """
    if q == 0:
        alpha = 0
    elif q == 1:
        alpha = steps * order / (2 * sigma**2)
    else:
        I_1 = quad(method_E_1, -np.inf, np.inf, args=(q,sigma, order, sensitivity))
        I_2 = quad(method_E_2, -np.inf, np.inf, args=(q,sigma, order, sensitivity))
        alpha = steps * np.log(max(I_1[0], I_2[0]))
    result = (alpha - math.log(delta)) / order
    return result

def get_epsilon(epoch, delta, sigma, sensitivity, batch_size, training_nums):
    """
    Compute epsilon with basic composition from given epoch, delta, sigma, sensitivity, batch_size and the number of training set.
    """
    q = batch_size / training_nums
    steps = int(math.ceil(epoch * training_nums / batch_size))
    epsilon = calculate_epsilon(q, sigma, steps, 1, delta, sensitivity)
    return epsilon



