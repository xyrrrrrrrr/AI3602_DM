import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
from encoders import BOWEncoder, SeqEncoder

'''
Reference: https://github.com/guxd/deep-code-search/blob/master/pytorch/models/jointemb.py
implement by myself according to the paper and this repo.
'''

class CodeNN(nn.Module):
    def __init__(self, config):
        super(CodeNN, self).__init__()
        self.conf = config
        self.margin = config['margin']
        # define encoder according to pixiv
        self.name_encoder=SeqEncoder(config['n_words'],config['emb_size'],config['lstm_dims'])
        self.token_encoder=BOWEncoder(config['n_words'],config['emb_size'],config['n_hidden'])
        self.desc_encoder=SeqEncoder(config['n_words'],config['emb_size'],config['lstm_dims'])
        # define similarity function and fuse layer
        self.w_name = nn.Linear(2*config['lstm_dims'], config['n_hidden'])
        self.w_token = nn.Linear(config['emb_size'], config['n_hidden'])
        self.w_desc = nn.Linear(2*config['lstm_dims'], config['n_hidden'])
        self.fuse3 = nn.Linear(config['n_hidden'], config['n_hidden'])
        
        self.init_weights()

    def code_encoding(self, name, name_len, tokens, tok_len):
        # encode name and tokens and fuse them to get code representation
        name_representation=self.name_encoder(name, name_len)
        token_representation=self.token_encoder(tokens, tok_len)
        # use tanh as activation function according to pixiv
        code_representation = self.fuse3(torch.tanh(self.w_name(name_representation)+self.w_token(token_representation)))
        
        return code_representation
    def desc_encoding(self, desc, desc_len):
        # encode description to get description representation
        desc_representation=self.desc_encoder(desc, desc_len)
        desc_representation=self.w_desc(desc_representation)

        return desc_representation
    
    def similarity(self, code_vec, desc_vec):
        # calculate cosine similarity between code and description
        return F.cosine_similarity(code_vec, desc_vec)

    def forward(self, name, name_len, tokens, tok_len, desc_anchor, desc_anchor_len, desc_neg, desc_neg_len):
        # define forward propagation
        code_representation = self.code_encoding(name, name_len, tokens, tok_len)
        desc_anchor_representation = self.desc_encoding(desc_anchor, desc_anchor_len)
        desc_neg_representation = self.desc_encoding(desc_neg, desc_neg_len)

        anchor_sim = self.similarity(code_representation, desc_anchor_representation)
        neg_sim = self.similarity(code_representation, desc_neg_representation)  

        loss = (self.margin - anchor_sim + neg_sim).clamp(min=1e-6).mean()

        return loss

    def init_weights(self):
        for m in [self.w_name, self.w_token, self.fuse3]:        
            m.weight.data.uniform_(-0.1, 0.1)
            nn.init.constant_(m.bias, 0.) 