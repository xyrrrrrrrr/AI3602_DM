import csv
import numpy as np
from numpy import argmax
from numpy.linalg import norm


DIMENSION = 100
TOTAL = 50000
CATEGORY = 5
THRESHOLD = 100

RANDOM_INIT_MEANS = False
# random initialing is faster but may fall into error
# while dispersed initialing costs time but has a stable performance.

data = np.zeros((TOTAL, DIMENSION))
means = np.zeros((CATEGORY, DIMENSION))
label = np.zeros(TOTAL, dtype=int)

def getData():
    global data
    with open("../data/features.csv", 'r') as csvFile:
        csvFile.readline()
        csv_reader = csv.reader(csvFile)
        PID = 0
        for row in csv_reader:
            data[PID] = row[1:] 
            PID += 1

def initRandomMeans():
    '''
    randomly choose CATEGORY data points as initial means
    '''
    global means
    choice = np.random.choice(TOTAL, CATEGORY, replace=False)
    means = data[choice]

def initDispersedMeans():
    global means
    choice = np.zeros(CATEGORY, dtype=int)
    choice[0] = np.random.randint(TOTAL)
    distance2Means = np.full(50000, np.infty)
    for i in range(CATEGORY-1):
        for candidate in range(TOTAL):
            distance2Means[candidate] = min(distance2Means[candidate], norm(data[candidate] - data[choice[i]]))
        choice[i+1] = argmax(distance2Means)
    means = data[choice]

def initMeans():
    if RANDOM_INIT_MEANS:
        initRandomMeans()
    else:
        initDispersedMeans()

def storeResult(filename, labelMap):
    with open(filename, 'w') as output:
        output.write("id,category\n")
        for i in range(TOTAL):
            output.write("{},{}\n".format(i, labelMap[label[i]]))

def mapLabelName():
    ### return the map: current cluster ID -> radius-sorted cluster ID
    radius = np.zeros(CATEGORY)
    ### TODO: calculate radius of each cluster and store them in var:radius ###
    for i in range(CATEGORY):
        for j in range(TOTAL):
            if label[j] == i:
                radius[i] = max(radius[i], norm(data[j] - means[i]))
    ### end of TODO ###
    temp =  radius.argsort()
    ranks = np.empty_like(temp)
    ranks[temp] = np.arange(CATEGORY)
    print("Radius: ")
    print(radius[temp])
    return ranks

### TODO ###
### you can define some useful function here if you want
import time

def calculateDistance():
    '''
    calculate the distance between each data point and each mean
    '''
    global data, means
    distance = np.zeros((TOTAL, CATEGORY))
    for i in range(TOTAL):
        for j in range(CATEGORY):
            distance[i][j] = norm(data[i] - means[j])
    return distance

def calculateLabel(distance):
    '''
    calculate the label of each data point
    '''
    global label
    delta_label = label.copy()
    for i in range(TOTAL):
        label[i] = np.argmin(distance[i])
        delta_label[i] = abs(label[i] - delta_label[i])
    if np.sum(delta_label) == 0:
        return False
    else:
        return True

def calculateMeans():
    '''
    calculate the mean of each cluster
    '''
    global data, label, means
    for i in range(CATEGORY):
        means[i] = np.zeros(DIMENSION)
        count = 0
        for j in range(TOTAL):
            if label[j] == i:
                means[i] += data[j]
                count += 1
        means[i] /= count

    
def kmeans():
    '''
    kmeans algorithm main body
    '''
    global data, means, label
    start_time = time.time()
    print('K-means start')
    count = 0
    while True:
        print('Iteration:', count)
        count += 1
        distance = calculateDistance()
        if not calculateLabel(distance) or count >= THRESHOLD:
            break
        calculateMeans()
    print('K-means finished in', time.time() - start_time, 'seconds', 'with', count, 'iterations')

### end of TODO ###
        

def main():
    getData()
    initMeans()
    ### TODO ###
    # implement your clustering alg. here
    kmeans()
    ### end of TODO ###
    labelMap = mapLabelName()
    storeResult("../data/predictions.csv", labelMap)


if __name__ == "__main__":
    main()
        
        