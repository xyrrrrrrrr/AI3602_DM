from .visitor import Visitor
# from visitor import Visitor
from typing import List


class MethodInvocationVisitor(Visitor):
    def __init__(self):
        super().__init__()
        self.method_invocation_list = []

    def get_method_invocations(self, code: str) -> List[str]:
        tree = self.parser.parse(code.encode())
        root = tree.root_node
        if root.has_error:
            raise ValueError('original code is invalid')
        class_body = root.children[0].children[3]
        for child in class_body.children:
            if child.type == 'method_declaration':
                for c in child.children:
                    if c.type == 'block':
                        for cc in c.children:
                            if cc.type == 'expression_statement':
                                for ccc in cc.children:
                                    if ccc.type == 'method_invocation':
                                        self.method_invocation_list.append(ccc)
                                        
                            if cc.type == 'while_statement':
                                for ccc in cc.children:
                                    if ccc.type == 'block':
                                        for cccc in ccc.children:
                                            if cccc.type == 'expression_statement':
                                                for ccccc in cccc.children:
                                                    if ccccc.type == 'method_invocation':
                                                        self.method_invocation_list.append(ccccc)
                                    if ccc.type == 'condition':
                                        for cccc in ccc.children:
                                            if cccc.type == 'binary_expression':
                                                for ccccc in cccc.children:
                                                    if ccccc.type == 'parenthesized_expression':
                                                        for cccccc in ccccc.children:
                                                            if cccccc.type == 'assignment_expression':
                                                                for ccccccc in cccccc.children:
                                                                    if ccccccc.type == 'method_invocation':
                                                                        self.method_invocation_list.append(ccccccc)
                                                                        print(ccccccc.text.decode())
                                                                        
                                                                            
        new_method_invocation_list = []
        for method_invocation in self.method_invocation_list:
            # process method_invocation
            new_method_invocation = ''
            if method_invocation.children[0].type == 'identifier':
                new_method_invocation += 'BufferedReader'
                for c in method_invocation.children[1:]:
                    if c.type == 'argument_list':
                        break
                    new_method_invocation += c.text.decode()
            else:
                for c in method_invocation.children:
                    if c.type == 'argument_list':
                        break
                    new_method_invocation += c.text.decode()
            new_method_invocation_list.append(new_method_invocation)
        del self.method_invocation_list
        self.method_invocation_list = new_method_invocation_list

                
                              
                                    
    

if __name__ == '__main__':
    visitor = MethodInvocationVisitor()
    visitor.get_method_invocations("public class MyClass {    public void readText(String file) {         BufferedReader br = new BufferedReader(new FileInputStream(file));         String line = null;         while ((line = br.readLine())!= null) {             System.out.println(line);         }         br.close();     }}"
)
    print(visitor.method_invocation_list)